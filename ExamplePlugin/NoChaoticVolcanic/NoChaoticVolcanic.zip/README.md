# Better Chaos Pool
Simply removes Volcanic Egg and Eccentric Vase from the Bottled Chaos pool.